using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.UI;

public class ScoreSystem : MonoBehaviour
{


    public static ScoreSystem instance;

    public Text ScoreText;
    public Text HighScoreText;

    int Score = 0;
    int Highscore = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private void Awake()
    {
        instance = this;
    }
    void Start()
    {
        ScoreText.text =  "SCORE: " + Score.ToString() ;
        HighScoreText.text = " HIGHSCORE: " + Highscore.ToString();
    }

    

    public void AddPoint()
    {
        Score+= 200;
        ScoreText.text = "SCORE: " + Score.ToString() ;
    }

}
