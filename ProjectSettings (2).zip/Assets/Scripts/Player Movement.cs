using System.Collections;
using UnityEditor.Tilemaps;
using UnityEngine;
using System.Collections.Generic;


public class PlayerMovement : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public Rigidbody2D rb2d;
    public float movespeed;
    public float jump = 15f;
    private float InputHorizontalLeft;
    private bool Facingright = true;

    private bool canDash = true;
    private bool isdashing;
    private float dashingPower = 15f;
    private float dashingTime = 0.3f;
    private float dashingCooldown = 1f;

    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundlayer;
    [SerializeField] private TrailRenderer Trail;
    Vector2 MoveDirection; 
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();

       
    }

    private bool Grounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundlayer);
    }

    // Update is called once per frame
    void Update()
    {

        if (isdashing)
        {
            return;
        }

        InputHorizontalLeft = Input.GetAxisRaw("Horizontal");
      
           
        if (Input.GetButtonDown("Jump") && Grounded())
        {
            rb2d.AddForce(new Vector2(rb2d.linearVelocity.x, jump));
        }

        else if (Input.GetButtonUp("Jump") && rb2d.linearVelocity.y > 0f)
        {
            rb2d.linearVelocity = new Vector2(rb2d.linearVelocityX, rb2d.linearVelocityY * 0.5f);
        }

        if (Input.GetKeyDown(KeyCode.LeftShift) && canDash)
        {
            StartCoroutine(Dash());
        }



        Flip();


    }




    private void FixedUpdate()
    {
        if (isdashing)
        {
            return;

        }
        rb2d.linearVelocity = new Vector2(InputHorizontalLeft * movespeed, rb2d.linearVelocityY);
    }

    private void Flip()
    {
        if (Facingright && InputHorizontalLeft <0f || !Facingright && InputHorizontalLeft > 0f)
        {
            Vector3 Localscale = transform.localScale;
            Facingright = !Facingright;
            Localscale.x *= -1f;
            transform.localScale = Localscale;
        }


    }

    private IEnumerator Dash()
    {
        canDash = false;
        isdashing = true;
        float originalGravity = rb2d.gravityScale;
        rb2d.gravityScale = 0f;
        rb2d.linearVelocity = new Vector2(transform.localScale.x * dashingPower, 0f);
        Trail.emitting = true;
        yield return new WaitForSeconds(dashingTime);
        Trail.emitting = false;
        rb2d.gravityScale = originalGravity;
        isdashing = false;
        yield return new WaitForSeconds(dashingCooldown);
        canDash = true;

    }

}
