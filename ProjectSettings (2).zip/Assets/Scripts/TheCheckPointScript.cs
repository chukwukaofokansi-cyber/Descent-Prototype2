using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class TheCheckPointScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private TheRespawnScript Respawning;
    private SpikeScript Spike;
    private BoxCollider2D collide;
    private BoxCollider2D spikeCollide;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    void Awake()
    {
        collide = GetComponent<BoxCollider2D>();
        Respawning = GameObject.FindGameObjectWithTag("Respawn").GetComponent<TheRespawnScript>();

        spikeCollide = GetComponent<BoxCollider2D>();
        Spike = GameObject.FindGameObjectWithTag("Spikes").GetComponent<SpikeScript>();


    }


    void Start()
    {

    }


    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Respawning.respawnPoint = this.gameObject;
            Spike.TheRespawn = this.gameObject; 
            collide.enabled = false; 
          
        }
    }

   



}
