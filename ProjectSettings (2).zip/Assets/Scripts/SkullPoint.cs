using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class SkullPoint : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void OnPlayerEnter2D(PlayerMovement Player)
    {
        Collectable(Player);
        

    }




    // Update is called once per frame
    private void Awake()
    {
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {

        ScoreSystem.instance.AddPoint();
        Destroy(gameObject);
    }
    void Collectable(PlayerMovement Player) { }

}
