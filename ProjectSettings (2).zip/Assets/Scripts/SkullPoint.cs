using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SkullPoint : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void OnTriggerEnter2D(Collider2D collision)
    {
        ScoreSystem.instance.AddPoint();
        Destroy(gameObject);



    }


   

    
    // Update is called once per frame
     




    
    

}
