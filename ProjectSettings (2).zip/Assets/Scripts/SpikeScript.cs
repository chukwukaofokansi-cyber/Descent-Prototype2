using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using Unity.VisualScripting;


public class SpikeScript : MonoBehaviour
{


    public GameObject ThePlayer;
    public GameObject TheRespawn;

    private void Start()
    {
      


    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("You've been hit");
            ThePlayer.transform.position = TheRespawn.transform.position;

        }
    }

    
    






}
