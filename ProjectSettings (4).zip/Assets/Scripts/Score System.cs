using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering;
using JetBrains.Annotations;

public class ScoreSystem : MonoBehaviour
{

    [SerializeField] TextMeshProUGUI HighScore;
    public static ScoreSystem instance;

    public Text ScoreText;
    

    int Score;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private void Awake()
    {
        instance = this;
    }
   
    public void AddPoint()
    {
        Score += 200;
        ScoreText.text = "SCORE " + Score;


        CheckHighScore();


    }//End of AddScore function 

    void CheckHighScore()
    {
        if (Score > PlayerPrefs.GetInt("HIGHSCORE", 0))
        {
            PlayerPrefs.SetInt("HIGHSCORE", Score);
            UpdateHighScore();
        }
    }

    void UpdateHighScore()
    {

        HighScore.text = $"HIGHSCORE {PlayerPrefs.GetInt("HIGHSCORE", 0)}";


    }

}
